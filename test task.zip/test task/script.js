document.querySelector('.squares').onclick = function(){
    let goods = document.querySelector('link');
    goods.href = 'style2.css';
}

document.querySelector('.rows').onclick = function(){
    let goods = document.querySelector('link');
    goods.href = 'style.css';
}